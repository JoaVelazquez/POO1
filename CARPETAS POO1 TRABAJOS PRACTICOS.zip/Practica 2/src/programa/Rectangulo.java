package programa;

public class Rectangulo extends Forma {
		
		private double ladoA;
		private double ladoB;
		
		public Rectangulo ( double ladoA, double ladoB ) {
			
			this.ladoA = ladoA;
			this.ladoB = ladoB;
			
		}
		
		@Override
		public double calculaArea() {
			
			double area = 0;
			area = ladoA * ladoB;
			return area;
			
		}
		
		public void setLadoA( double ladoA ) {
			
			this.ladoA = ladoA;
			
		}
		
		public void setLadoB( double ladoB ) {
			
			this.ladoB = ladoB;
			
		}
		
		public double getLadoA() {
			
			return ladoA;
			
		}
		
		public double getLadoB() {
			
			return ladoB;
			
		}
}
