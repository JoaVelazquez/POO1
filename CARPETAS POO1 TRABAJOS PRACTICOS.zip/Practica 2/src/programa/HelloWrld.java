package programa;

public class HelloWrld {
	
	public static void main(String[] args) {
		System.out.println("Hello World!");
	}
}
