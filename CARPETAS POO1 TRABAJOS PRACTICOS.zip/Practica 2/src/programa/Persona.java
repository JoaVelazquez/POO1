package programa;

import java.time.LocalDate;
import java.time.Period;

public class Persona {
	
	private String nombre;
	private int edad;
	
	public void setNombre( String nombre ) {
		this.nombre = nombre;
	}
	
	public void setEdad( int edad ) {
		this.edad = edad;
	}
	
	public String getNombre( String nombre ) {
		return nombre;
	}
	
	public int getEdad( int edad ) {
		return edad;
	}
	
	private static int CalculaEdad(int anioNac ,int mesNac ,int diaNac ) {
		LocalDate fechaNac = LocalDate.of( anioNac, mesNac, diaNac );
		LocalDate fechaActual = LocalDate.now();
		Period difFechas = Period.between(fechaNac,fechaActual);
		int edad = difFechas.getYears();
		
		return edad;
	}
	public Persona( String nombre, int edad) {
		this.nombre = nombre;
		this.edad = edad;
	}
	
	public Persona( String nombre, String fechaNac ) {
		
		String [] infoFecha = fechaNac.split("/");
		int anioNac = Integer.parseInt(infoFecha[2]);
		int mesNac = Integer.parseInt(infoFecha[1]);
		int diaNac = Integer.parseInt(infoFecha[0]);
		
		this.setNombre(nombre);
		this.setEdad(CalculaEdad(anioNac, mesNac, diaNac ));
		
		
	}
	@Override
	public String toString() {
		return "Nombre: " + nombre + " - Edad: " + edad;
	}
}
