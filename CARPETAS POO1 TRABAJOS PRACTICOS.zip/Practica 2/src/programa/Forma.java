package programa;

public abstract class Forma {
	
	public abstract double calculaArea();
	
}
