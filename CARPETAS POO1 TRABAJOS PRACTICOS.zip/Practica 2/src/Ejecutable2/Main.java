package Ejecutable2;

import programa.Persona;

public class Main {
	
	public static void main( String[] args ) {
		
			Persona Usuario1 = new Persona("Joaquin",20);
			Persona Usuario2 = new Persona("Videla","30/11/1999");
			
			System.out.println( Usuario1.toString());
			System.out.println( Usuario2.toString());
	}
}
