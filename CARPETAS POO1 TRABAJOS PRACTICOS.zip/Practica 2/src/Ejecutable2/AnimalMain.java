package Ejecutable2;

import programa.Animal;
import programa.Perro;

public class AnimalMain {
		
	public static void main( String[] args ) {
		
		Perro perro1 = new Perro( "Maika", "Maltez" );
		
		System.out.println("Es un "+perro1.getRaza());
	}
}
