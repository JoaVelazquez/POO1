package Ejecutable2;

import programa.Forma;
import programa.Rectangulo;
import programa.Circulo;
import programa.Triangulo;

public class FormaMain {
	
	public static void main( String[] args) {
		
		Rectangulo rect = new Rectangulo (5,6);
		Circulo circ = new Circulo(5);
		Triangulo tria = new Triangulo(8,6);
		
		System.out.println( rect.calculaArea());
		System.out.println( circ.calculaArea());
		System.out.println( tria.calculaArea());
		
	}
}
