package Ejecutable2;

import programa.Persona2;

public class Persona2Main {

	public static void main( String[] args ) {
		
		Persona2 usuario = new Persona2("Joaquin","Velazquez");
		
		System.out.println(usuario);
	}
}
