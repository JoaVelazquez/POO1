package Ejemplo;
 
public class Punto {
	private int coordX;
	private int coordY;
	
	public Punto( int coordX, int coordY) {
		
		this.coordX = coordX;
		this.coordY = coordY;
	}
	
	public String toString() {
		return"(" + coordX + "," 
	}
}
