package Ejemplo;

public class EjemplosConsola {

		public static void main(String[] args) {
			int dividendo = 9;
			int divisorEntero = 2;
			double divisorDecimal =2.0;
			
			System.out.print("Division Entera:");
			System.out.println();
			System.out.print(dividendo + "/" + divisorEntero + "=" + dividendo/divisorEntero);
			System.out.println();
			
			System.out.println("Division Entera");
			System.out.println(dividendo + "/" + divisorDecimal + "=" + dividendo/divisorDecimal);
			System.out.println();
			
		}
}
