package Ejemplo;

import java.util.Scanner;

public class EjemplosScanner {

		public static void main(String[] args) {
			Scanner teclado = new Scanner(System.in);
			/*
			System.out.print("Ingrese un numero: ");
			int nro = teclado.nextInt();
			System.out.println(">> Numero ingresado: " + nro);
			
			teclado.nextLine();
		
			System.out.print("Ingrese una frase: ");
			String frase = teclado.nextLine();
			System.out.println(">> Frase ingresada: " + frase);
			
			System.out.print("Ingrese otra frase:");
			String otraFrase = teclado.nextLine();
			System.out.println(">> Otra frase ingresada: " + otraFrase);
			
			for(String palabra : otraFrase.split(" ")) {
				System.out.println(">>" + palabra);
			}
			
			System.out.print("Ingrese un caracter: ");
			char character = teclado.next().charAt(0);
			System.out.println(">> El caracter ingresado es: " + character);
			System.out.println(">> La info que queda en el buffer es: " + teclado.nextLine());
			
			teclado.nextLine();
			
			System.out.print("Ingrese dos palabras: ");
			String primeraPalabra = teclado.next();
			String segundaPalabra = teclado.next();
			System.out.println("Primera palabra: " + primeraPalabra + "\nSegunda Palabra: " + segundaPalabra);
			
			teclado.nextLine();
			
			String fraseN;
			
			System.out.print("Ingrese varias frases (doble enter para terminar): ");
			while( teclado.hasNextLine()) {
				fraseN = teclado.nextLine();
				
				if(!fraseN.isEmpty())
					System.out.println(">> frase ingresada: "+ fraseN);
				else
					break;
			}
			
			int positivo;
			
			do {
				
				System.out.print("Ingrese un numero positivo: ");
				while(!teclado.hasNextInt()) {
					
					System.out.println(" El numero ingresado no es entero positivo\n");
					teclado.next();
				}
				positivo = teclado.nextInt();
			}while(positivo<=0);
			
			System.out.println(">> El num positivo ingresado es:" + positivo);
			*/
			
			String vocal;
			System.out.println("Ingrese una vocal mayuscula: ");
			while(!teclado.hasNext("[AEIOU]")) {
				System.out.println("Esa no es una vocal mayuscula!");
				teclado.next();
			}
			vocal = teclado.next();
			System.out.println(">>caracter: " + vocal);
			teclado.close();
		}
}
