package domain;

import java.util.List;
import java.util.*;
import java.util.Random;

public class Mesa {
	
	static int repeticiones;
	static 	List<Integer> lista;
	
	public Mesa() {
		lista = new ArrayList<>();
	}
	
	public void setRepeticiones(int repeticiones) {
		this.repeticiones = repeticiones;
		
	}
	public int getRepeticiones() {
		return repeticiones;
	}
	
	
	public int realizarPruebaBalanceo() throws MesaDesbalanceadaException{
		
		int i,j;
		int contador = 0,maxRepeticiones = 0;
		
		for( i=0 ; i<100 ; i++) {
			
			Random r = new Random();
            Integer numRandom = r.nextInt(37);
            lista.add(numRandom);
            System.out.println( "Numero "+i+"al azar: "+numRandom);
		}
		
		for(i=0 ; i<99 ; i++) {
			for(j=1 ; j<100 ; j++) {
				
				if( lista.get(i) == lista.get(j) ) {
					contador+=1;
				}
				
			}if( contador > maxRepeticiones ) {
				maxRepeticiones = contador;
			}
			if ( contador >= 10 ) {
				throw new MesaDesbalanceadaException(lista.get(i));
			}
			contador = 0;
		}
		return maxRepeticiones;
	}
	
	
	
}