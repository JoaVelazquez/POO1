package domain;

public class MesaDesbalanceadaException extends Exception {
	
	public MesaDesbalanceadaException(int numero) {
		super("La mesa esta desbalanceada!, y el numero que mas salio es "+numero);
	}
	
}
