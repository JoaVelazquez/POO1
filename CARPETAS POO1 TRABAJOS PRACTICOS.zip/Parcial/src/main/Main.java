package main;

import domain.Mesa;

public class Main {

	public static void main(String[] args) {
		
		Mesa mesaUno = new Mesa();
		
		try {
			System.out.println(mesaUno.realizarPruebaBalanceo());
		}catch (Exception exception) {
			System.out.println(exception.getMessage());
		}
	}

}
