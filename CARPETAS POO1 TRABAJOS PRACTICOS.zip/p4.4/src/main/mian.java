package main;

import domain.Fecha;
import domain.ManejadorDeFechas;

public class mian {

	public static void main(String[] args) {
		try {
			Fecha unaFecha = new Fecha(1,2,2020);
			System.out.println("Creamos una fecha X: "+unaFecha);
			System.out.println("Formateo la fecha X: "+ ManejadorDeFechas.formatearFecha(unaFecha));
		}catch(Exception exception) {
			System.out.println(exception.getMessage());
		}

	}

}
