package domain;

import java.util.Calendar;

public class ManejadorDeFechas {
	
	
	public static String formatearFecha(Fecha fecha) {
		String dia=null;
		String mes=null;
		String anio=null;
		
		if( fecha.dia >10) {
			dia = Integer.toString(fecha.dia);
		}else {
			dia ="0"+ Integer.toString(fecha.dia);
		}

		if( fecha.mes > 10) {
			mes = Integer.toString(fecha.mes);
		}
		else {
			mes = "0"+Integer.toString(fecha.mes);
		}
		if( fecha.anio > 999 ) {
			anio = Integer.toString(fecha.anio);
		}else if( fecha.anio > 99 && fecha.anio < 999 ) {
			anio = "0"+Integer.toString(fecha.anio);
		}else if ( fecha.anio > 0 && fecha.anio < 99 ) {
			anio = "00"+Integer.toString(fecha.anio);
		}
		
		String fechaStr = dia+"/"+mes+"/"+anio;
		return fechaStr;
	}
	
	public static Fecha parsearFecha(String fecha) throws Exception {
		
		Fecha fechaNueva = null;
		String[] partesDeFecha = fecha.split("/");
		int dia;
		int mes;
		int anio;
		dia = Integer.parseInt(partesDeFecha[0]);
		mes = Integer.parseInt(partesDeFecha[1]);
		anio = Integer.parseInt(partesDeFecha[2]);
		
		fechaNueva.dia = dia;
		fechaNueva.mes = mes;
		fechaNueva.anio = anio;
		return fechaNueva;
		
	}
	
	public static int cantidadDeAnios(Fecha fecha) {
		int anioActual = Calendar.getInstance().get(Calendar.YEAR);
		int dif;
		
		dif = Math.abs(anioActual - fecha.anio);
		return dif;
	}
	
}
