package domain;

public class ParseadorDeFecha {
	
	public static String parsearFecha(String fecha) throws FormatoInvalido {
		
		String[] partesDeFecha = fecha.split("/");
		int dia;
		int mes;
		int anio;
		dia = Integer.parseInt(partesDeFecha[0]);
		mes = Integer.parseInt(partesDeFecha[1]);
		anio = Integer.parseInt(partesDeFecha[2]);
		
		if( esFecha(dia,mes,anio) ) {
			return "Es valida";
		}else {
			throw new FormatoInvalido();
		}
		
	}

		
		
		private static boolean esDia(int dia){
			
			if( dia>0 && dia<31) {
				return true;
			}
			return false;
		}
		private static boolean esMes(int mes){
			
			if ( mes>0 && mes<12) {
				return true;
			}
			return false;
		}
		private static boolean esAnio(int anio){
			
			if( anio>0) {
				return true;
			}
			return false;
		}
		
		
		
		private static boolean esFecha(int dia, int mes, int anio){
			
			if( esDia(dia) && esMes(mes) && esAnio(anio) ) {

	            if ( mes == 2) {
	                if ( !esBisiesto(anio) && (dia > 28)) {
	                    return false;
	                }
	                if ( esBisiesto(anio) && (dia >29) ) {
	                    return false;
	                }
	            }

	            else if ( !(mes == 1 || mes == 3 || mes == 5 || mes == 7 || mes == 8 || mes == 10 || mes == 12) && (dia == 31) ) {
	                return false;
	            }

	            return true;
	        }
	        return false;
	    }
		
		private static boolean esBisiesto(int anio) {
			
			if ((anio % 4 == 0) && ((anio % 100 != 0) || (anio % 400 == 0))) {
			    return true;
			}else {
			    return false;
			}
		}
		
}
