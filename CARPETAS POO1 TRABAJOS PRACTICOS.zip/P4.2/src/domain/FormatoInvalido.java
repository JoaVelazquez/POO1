package domain;

public class FormatoInvalido extends Exception{
	
	public FormatoInvalido() {
		super("Formato invalido de fecha!");
	}

}
