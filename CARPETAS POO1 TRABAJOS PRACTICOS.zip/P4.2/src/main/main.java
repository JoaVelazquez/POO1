package main;

import domain.ParseadorDeFecha;

public class main {

	public static void main(String[] args) {
		
		String fecha = "29/2/2020";
		
		try {
			System.out.println(ParseadorDeFecha.parsearFecha(fecha));
		}catch (Exception exception) {
			System.out.println(exception.getMessage());
		}
	}

}
