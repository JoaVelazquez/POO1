package Main;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

import Domain.*;
public class main {

	public static void main(String[] args) throws IOException {
		
		//CREO 3 RECTANGULOS
		Rectangulo rec1 = new Rectangulo(10,5);
		Rectangulo rec2 = new Rectangulo(20,15);
		Rectangulo rec3 = new Rectangulo(5,8);
		
		//CREO 3 CIRCULOS
		Circulo cir1 = new Circulo(5);
		Circulo cir2 = new Circulo(8);
		Circulo cir3 = new Circulo(2);

		//CREO UNA LISTA PARA CADA UNO Y LAS IMPRIMIMOS
		List<Rectangulo> listRec = new ArrayList<>();
		List<Circulo> listCir = new ArrayList<>();
		
		listRec.add(rec1);
		listRec.add(rec2);
		listRec.add(rec3);
		
		listCir.add(cir1);
		listCir.add(cir2);
		listCir.add(cir3);
		
		System.out.println(">>IMPRIMO LISTA DE CIRCULOS:\n");
		for( Circulo circulo : listCir ) {
			
			System.out.println(circulo.toString());
			System.out.println("Area = "+circulo.calcularArea());
			System.out.println("Perimetro = "+circulo.calcularPerimetro());
			
		}
		
		System.out.println("\n\n>>IMPRIMO LISTA DE RECTANGULOS:\n");
		for( Rectangulo rectangulo : listRec ) {
			
			System.out.println(rectangulo.toString());
			System.out.println("Area = "+rectangulo.calcularArea());
			System.out.println("Perimetro = "+rectangulo.calcularPerimetro());
			
		}
		//CREO DOS ARCHIVOS BINARIOS A PARTIR DE LAS LISTAS
		
		ObjectOutputStream archCir = null;
		ObjectOutputStream archRec = null;
		
		try {
			
			archCir = new ObjectOutputStream(new BufferedOutputStream(new FileOutputStream("circulo.fig")));
			archRec = new ObjectOutputStream(new BufferedOutputStream(new FileOutputStream("rectangulo.fig")));
			
			for( Circulo circulo : listCir ) 
				archCir.writeObject(circulo);
			
			for( Rectangulo rectangulo : listRec ) 
				archRec.writeObject(rectangulo);
			
			
		} catch (IOException e) {
		}
		
		finally {
			if(archCir != null && archRec != null ) {
				archCir.close();
				archRec.close();
			}
		}
		System.out.println("\n\n>>Se escribieron los archivos binarios!");
		
		
		//LEO LOS ARCHS CREADOS
		
		ObjectInputStream archCirLec = null;
		ObjectInputStream archRecLec = null;
		
		try {
			archCirLec = new ObjectInputStream(new BufferedInputStream(new FileInputStream("circulo.fig")));
			archRecLec = new ObjectInputStream (new BufferedInputStream(new FileInputStream("rectangulo.fig")));
			
			try {
				System.out.println("\n>>LECTURA ARCH BIN CIRCULOS");
				while(true) {
					System.out.println(((Circulo)archCirLec.readObject()).toString());
				}
			}catch(EOFException | ClassNotFoundException e) {
				
			}
				
			try {
				System.out.println("\n>>LECTURA ARCH BIN RECTANGULOS");
				while(true) {
					System.out.println(((Rectangulo)archRecLec.readObject()).toString());
				}
			}catch(EOFException | ClassNotFoundException e) {
				
				}
				
			}
		
		finally {
				if(archCir != null && archRec != null ) {
					archCirLec.close();
					archRecLec.close();
				}
			}
		
	}
}



















