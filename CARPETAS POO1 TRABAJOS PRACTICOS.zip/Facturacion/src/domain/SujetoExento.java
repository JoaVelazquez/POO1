package domain;

public class SujetoExento extends IVA{
	
	@Override
	public double calculaIVA( double precio ) {
		return precio;
	}
}
