package domain;

import java.util.ArrayList;
import java.util.List;
public class Factura {
	
	List<Producto> listCompras;
	private Cliente cliente;
	
	public Factura(Cliente cliente) {
		
		listCompras = new ArrayList<>();
		this.cliente = cliente;
	}
	//AGREGO LOS ELEMENTOS A LA LISTA
	public void agregaProducto(Producto producto) {
		listCompras.add(producto);
	}

	public double calculaPrecioFinal() {
		double precioFinal =0;
		for( Producto producto: listCompras) {
			precioFinal = precioFinal + producto.getPrecioModificado();
		}
		return cliente.getIVA().calculaIVA(precioFinal);
	}
	
	public void imprimeLista() {
		for( Producto producto: listCompras) {
			System.out.print(producto);
		}
	}
	
	//SETTERS Y GETTERS
	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}
	public Cliente getCliente() {
		return cliente;
	}

}
