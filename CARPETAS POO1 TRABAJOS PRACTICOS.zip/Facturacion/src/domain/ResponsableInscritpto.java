package domain;

public class ResponsableInscritpto extends IVA {

		@Override
		public double calculaIVA( double precio) {
			return precio*1.105;
		}
}
