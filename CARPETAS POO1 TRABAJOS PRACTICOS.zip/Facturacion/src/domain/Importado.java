package domain;

public class Importado extends Categoria{
	
	@Override
	public double getPrecio(double precio) {
		return precio*1.1;
	}
}
