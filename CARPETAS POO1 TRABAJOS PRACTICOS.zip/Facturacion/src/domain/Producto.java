package domain;

public class Producto {
	
	private String nombre;
	private double precioOriginal;
	private double precioModificado;
	public Categoria categoria;
	
	public Producto(String nombre, double precioOriginal, Categoria categoria) {
		
		this.categoria = categoria;
		this.nombre = nombre;
		this.precioOriginal = precioOriginal;
		this.precioModificado = categoria.getPrecio(precioOriginal);
		
	}
	
	@Override
	public String toString() {
		return "\nProducto: "+nombre+"\nPrecio sin recarga: $"+precioOriginal;
	}
	
	//SETTERS Y GETTERS
	public void setNombre( String nombre ) {
		this.nombre = nombre;
	}
	public String getNombre() {
		return nombre;
	}
	
	public void setPrecioOriginal(double precioOriginal) {
		this.precioOriginal = precioOriginal;
	}
	public double getPrecioOriginal() {
		return precioOriginal;
	}
	
	public void setPrecioModificado(double precioModificado) {
		this.precioModificado = precioModificado;
	}
	public double getPrecioModificado() {
		return precioModificado;
	}
	
	public void setCategoria(Categoria categoria) {
		this.categoria = categoria;
	}
	public Categoria getCategoria() {
		return categoria;
	}
	
}
