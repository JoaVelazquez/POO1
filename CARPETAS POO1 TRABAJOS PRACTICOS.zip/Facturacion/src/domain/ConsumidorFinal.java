package domain;

public class ConsumidorFinal extends IVA{
		
	@Override
	public double calculaIVA( double precio) {
		return precio*1.21;
	}
}
