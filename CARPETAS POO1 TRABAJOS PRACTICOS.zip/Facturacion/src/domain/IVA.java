package domain;

public abstract class IVA {
	//DEPENDIENDO DE QUE TIPO DE IVA SE APLIQUE A CADA PERSONA SE MODIFICARA EL PRECIO
	public abstract double calculaIVA( double precio);
}
