package domain;

public class Nacional extends Categoria{
	
	@Override
	public double getPrecio(double precio) {
		return precio;
	}

}
