package domain;

public abstract class Categoria {
	//MISMO CONCEPTO QUE IVA, DEPENDIENDO DE QUE TIPO DE PRODUCTO SEA SE MODIFICARA SU PRECIO
	public abstract double getPrecio(double precio);
}
