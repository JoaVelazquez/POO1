package domain;
import java.util.List;
import java.util.ArrayList;

public class Mercado {
	//CREO UN LUGAR DONDE PUEDA ALMACENAR LOS PRODUCTOS
	private String nombre;
	List<Producto> listaProductos;
	public Mercado(String nombre) {
		this.nombre = nombre;
		listaProductos = new ArrayList<>();
	}

	public void setNombre( String nombre) {
		this.nombre = nombre;
	}
	
	public String getNombre() {
		return nombre;
	}
	
	public void agregarProducto(Producto producto) {
		listaProductos.add(producto);
	}

	public void imprimeListaProductos() {
		for(Producto producto : listaProductos ) {
			System.out.println(producto);
		}
	}
}
