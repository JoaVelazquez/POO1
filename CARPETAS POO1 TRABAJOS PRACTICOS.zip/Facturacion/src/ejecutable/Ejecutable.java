package ejecutable;

import domain.*;

public class Ejecutable {

	public static void main(String[] args) {
		//GENERO DONDE ESTARAN LOS PRODUCTOS
		Mercado mercado = new Mercado("Supermercado");
		
		
		//GENERO LOS PRODUCTOS Y LOS AGREGAMOS A UNA LISTA
		
		Producto computadora = new Producto("Computadora",60000, new Importado());
		Producto vajillas = new Producto("Vajillas",7000, new Nacional());
		Producto heladera = new Producto("Heladera",45000, new Nacional());
		
		mercado.agregarProducto(computadora);
		mercado.agregarProducto(vajillas);
		mercado.agregarProducto(heladera);
		
		
		//CREO PERFILES DE CLIENTES
		Cliente florencia = new Cliente("Florencia", new ResponsableInscritpto());
		Cliente luis = new Cliente("Luis", new ConsumidorFinal());
		Cliente pedro = new Cliente("Pedro", new SujetoExento());
		
		//VERIFICO QUE TODOS LOS PRODUCTOS ESTEN EN EL PROGRAMA
		System.out.println("\nProductos disponibles:");
		mercado.imprimeListaProductos();
		
		//PARA CADA CLIENTE GENERO UNA FACTURA CON SU PRODUCTO CORRESPONDIENTE
		Factura factura1 = new Factura(florencia);
		Factura factura2 = new Factura(luis);
		Factura factura3 = new Factura(pedro);
		factura1.agregaProducto(computadora);
		factura2.agregaProducto(vajillas);
		factura3.agregaProducto(heladera);

		//IMPIMO LOS RESULTADOS
		System.out.println("\n_____________________________________");
		System.out.println("\nLista del cliente: ");
		System.out.println("Producto(s) de Florencia:");
		factura1.imprimeLista();
		System.out.println("\n\nProducto(s) de Luis:");
		factura2.imprimeLista();
		System.out.println("\n\nProducto(s) de Pedro:");
		factura3.imprimeLista();
		System.out.println("\n_____________________________________");
		System.out.println("\nImprimo facturas de clientes: ");
		System.out.println("\nLa factura de "+florencia.getNombre()+" es de $"+factura1.calculaPrecioFinal());
		System.out.println("\nLa factura de "+luis.getNombre()+" es de $"+factura2.calculaPrecioFinal());
		System.out.println("\nLa factura de "+pedro.getNombre()+" es de $"+factura3.calculaPrecioFinal());

		
	}

}