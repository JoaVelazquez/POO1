package Main;

import Domain.Cliente;
import Domain.ListaRemedios;
import Domain.Remedios;

public class main {

	public static void main(String[] args) {
		

		Cliente carlos = new Cliente("Carlos", "Lopez", "OSPLAD");
		Cliente ana = new Cliente("Ana", "Diaz", "");
		Cliente fernando = new Cliente("Fernando", "Gomez", "OSOCNA");
		
		ListaRemedios lista = new ListaRemedios();
		Remedios dermaglos = new Remedios("Dermaglos", 100, false);
		Remedios adermicina = new Remedios("Adermicina", 240, false);
		Remedios macril = new Remedios("Macril", 180, true);
		
		lista.agrega(dermaglos);
		lista.agrega(adermicina);
		lista.agrega(macril);
		
		//Compras
		
		carlos.Pedido(macril, true);
		ana.Pedido(dermaglos, false);
		fernando.Pedido(adermicina, false);
		
	
		
		
	}

}
