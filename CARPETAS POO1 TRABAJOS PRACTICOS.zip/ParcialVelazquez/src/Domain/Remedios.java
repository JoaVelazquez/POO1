package Domain;

public class Remedios {

		private String nombre;
		private double precio;
		private boolean receta;
		
		public Remedios(String nombre,double precio, boolean receta) {
			this.nombre = nombre;
			this.precio = precio;
			this.receta = receta;
		}
		//Establecemos los descuentos por metodo de pago
		
		public void PagoEfectivo() {
			this.precio = precio - (precio* 0.10);//Si Paga en efectivo le descontamos 10%
		}
		
		public void PagoTarjeta() {
			this.precio = precio + (precio*0.05);//Si paga con tarjeta le recargamos5%
		}
		
		//Establecemos los descuentos por obra social
		
		public void TieneObraSocial() {
			//Tenemos dos casos, con o sin receta
			if(this.receta) {
				this.precio = precio - (precio*0.60);
			}else {
				this.precio = precio - (precio*0.90);
			}
			
		}
		//Setters y Getters
		public void setNombre(String nombre) {
			this.nombre = nombre;
		}
		
		public String getNombre() {
			return nombre;
		}
		
		public void setPrecio(int precio) {
			this.precio = precio;
		}
		
		public double getPrecio() {
			return precio;
		}
		
		public void setReceta(boolean receta) {
			this.receta = receta;
		}
		
		public boolean getReceta() {
			return receta;
		}
}
