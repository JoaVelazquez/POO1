package Domain;

public class Cliente {

		public String nombre;
		public String apellido;
		public String obraSocial;
		
		public Cliente(String nombre, String apellido, String obraSocial) {
			this.nombre = nombre;
			this.apellido = apellido;
			this.obraSocial = obraSocial;
		}
		
		
		public void Pedido(Remedios remedio, boolean Efectivo ) {
			
			//si el arg efectivo == true, se aplicara el descuento correspondiente
			
			if( Efectivo ) {
				remedio.PagoEfectivo();
			}else {
				remedio.PagoTarjeta();
			}
			if( obraSocial != "" ) {
				remedio.TieneObraSocial();
			}
			System.out.println(this.nombre +" "+ this.apellido + " compro "+remedio.getNombre()+ " a $" + remedio.getPrecio());
		}
		//Setters y Getters		
		public void setNombre(String nombre) {
			this.nombre = nombre;
		}
		public String getNombre() {
			return nombre;
		}
		public void setApellido(String apellido) {
			this.apellido = apellido;
		}
		public void setObraSocial(String obraSocial) {
			this.obraSocial = obraSocial;
		}
		public String getObraSocial() {
			return obraSocial;
		}
	
		
}
