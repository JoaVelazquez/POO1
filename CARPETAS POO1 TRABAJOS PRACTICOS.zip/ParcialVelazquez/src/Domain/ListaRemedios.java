package Domain;

import java.util.ArrayList;
import java.util.List;

public class ListaRemedios {
	
		static List<Remedios> lista= null;
		
		public ListaRemedios() {
			lista = new ArrayList<>();
		}
		public List<Remedio> getLista(){
			return lista;
		}
		public void agrega(Remedios remedio) {//se genera un inventario
			lista.add(remedio);
		}
		
}
