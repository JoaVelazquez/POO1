package programa;

import dominio.Cliente;
import dominio.Efectivo;
import dominio.Farmacia;
import dominio.ObraSocial;
import dominio.Remedio;
import dominio.SinObraSocial;
import dominio.Tarjeta;

public class Prueba {

	public static void main(String[] args) {

		//CREO LA FARMACIA
		Farmacia farmacity = new Farmacia();
		System.out.println(farmacity.toString());
		
		//CREO LOS REMEDIOS
		Remedio dermaglos = new Remedio("Dermaglos", 100, false);
		Remedio adermicina = new Remedio("Adermicina", 240, false);
		Remedio macril = new Remedio("Macril", 180, true);

		//AGREGO LOS REMEDIOS A LA LISTA DE LA FARMACIA
		farmacity.agregarRemedio(dermaglos);
		farmacity.agregarRemedio(adermicina);
		farmacity.agregarRemedio(macril);
		
		//PRUEBO QUE SE HAYA CREADO BIEN LA LISTA DE REMEDIOS
		System.out.println("\n Imprimo la lista de Remedios cargada:");
		for(Remedio remedio: farmacity.getListaDeRemedios()) {
			System.out.println(remedio.toString());
		}
		
		//CREO LOS CLIENTES
		System.out.println("\n Creo e imprimo los clientes creados:");
		
		Cliente cliente1 = new Cliente("Carlos", new ObraSocial("OSPLAD"));
		System.out.println(cliente1.toString());
		Cliente cliente2 = new Cliente("Ana", new SinObraSocial());
		System.out.println(cliente2.toString());
		Cliente cliente3 = new Cliente("Fernando",new ObraSocial("OSOCNA"));
		System.out.println(cliente3.toString());
		
		
		//HAGO LAS COMPRAS SOLICITADAS EN EL ENUNCIADO
		System.out.println("\n Hago las 3 distintas compras con los clientes:");
		
		System.out.println("Compra 1: Total a Pagar= $" + farmacity.calcularImporteAPagar(cliente1, macril, new Efectivo()));
		System.out.println("Compra 2: Total a Pagar= $" + farmacity.calcularImporteAPagar(cliente2, dermaglos, new Tarjeta()));
		System.out.println("Compra 3: Total a Pagar= $" + farmacity.calcularImporteAPagar(cliente3, adermicina, new Tarjeta()));

		
	}

}
