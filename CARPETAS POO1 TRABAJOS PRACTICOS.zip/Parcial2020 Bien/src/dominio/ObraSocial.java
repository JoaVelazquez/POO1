package dominio;

public class ObraSocial {
	
	private String nombre;
	
	public ObraSocial(String nombre) {
		this.nombre = nombre;
	}
	
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	public String getNombre() {
		return nombre;
	}

	public double calcularDescuento(Remedio remedio) {
		
		if(remedio.getNecesitaReceta()) {
			return remedio.getPrecioDeLista() * 0.6;
		}
		
		else {
			return remedio.getPrecioDeLista() * 0.9;
		}
	}
	
	@Override
	public String toString() {
		return nombre;
	}
}
