package dominio;

public class Cliente{

	private String nombre;
	private ObraSocial obraSocial;
	
	public Cliente(String nombre, ObraSocial obraSocial) {
		
		this.nombre = nombre;
		this.obraSocial = obraSocial;
	}
	
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	public void setObraSocial(ObraSocial obraSocial) {
		this.obraSocial = obraSocial;
	}
	
	public String getNombre() {
		return nombre;
	}
	
	
	public ObraSocial getObrasocial() {
		return obraSocial;
	}
	
	@Override
	public String toString() {
		return ">> Soy: " + nombre +  " y mi Obra Social es: "+ obraSocial;
	}
	
	
}
