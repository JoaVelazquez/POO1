package dominio;

public class Tarjeta extends MedioDePago{

	@Override
	public double calcularValorAPagar(double precio) {
		return precio * 1.05;
	}
}
