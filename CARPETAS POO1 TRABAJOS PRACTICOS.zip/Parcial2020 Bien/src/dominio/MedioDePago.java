package dominio;

public abstract class MedioDePago {
	
	public abstract double calcularValorAPagar(double precio);

}
