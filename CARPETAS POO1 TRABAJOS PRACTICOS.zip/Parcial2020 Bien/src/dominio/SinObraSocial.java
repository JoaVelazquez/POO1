package dominio;

public class SinObraSocial extends ObraSocial{
	
	public SinObraSocial() {
		super("");
	}
	
	public double calcularDescuento(Remedio remedio) {
		return remedio.getPrecioDeLista();
	}

}
