package dominio;

public class Efectivo extends MedioDePago{

	@Override
	public double calcularValorAPagar(double precio) {
		return precio * 0.9;
	}
}
