package dominio;

import java.util.ArrayList;
import java.util.List;

public class Farmacia {

	static List<Remedio> listaDeRemedios;
	
	public Farmacia() {
		
		listaDeRemedios = new ArrayList<>();
	}
	
	public List<Remedio> getListaDeRemedios(){
		return listaDeRemedios;
	}
	
	public void agregarRemedio(Remedio remedio) {
		listaDeRemedios.add(remedio);
	}
	
	public void eliminarRemedio(Remedio remedio) {
		listaDeRemedios.remove(remedio);
	}
	
	@Override
	public String toString() {
		return "\n La Farmacia fue creada con exito!";
	}
	
	public double calcularImporteAPagar(Cliente cliente, Remedio remedio, MedioDePago medioDePago) {
		ObraSocial obraSocial = cliente.getObrasocial();
		
		double precioConDescuento = obraSocial.calcularDescuento(remedio);
		
		double precioFinal = medioDePago.calcularValorAPagar(precioConDescuento);
		
		return precioFinal;
	}
}
