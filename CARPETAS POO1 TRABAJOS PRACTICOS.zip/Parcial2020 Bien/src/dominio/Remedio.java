package dominio;

public  class Remedio {

	private String nombre;
	private double precioDeLista;
	private boolean necesitaReceta;
	
	public Remedio(String nombre, double precioDeLista, boolean necesitaReceta) {
		this.nombre = nombre;
		this.precioDeLista = precioDeLista;
		this.necesitaReceta = necesitaReceta;
	}
	
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	public void setPrecioDeLista(double precioDeLista) {
		this.precioDeLista = precioDeLista;
	}
	
	public void setNecesitaReceta(boolean necesitaReceta) {
		this.necesitaReceta = necesitaReceta;
	}
	
	public String getNombre() {
		return nombre;
	}
	
	public double getPrecioDeLista() {
		return precioDeLista;
	}
	
	public boolean getNecesitaReceta() {
		return necesitaReceta;
	}		

	@Override
	public String toString() {
		return ">> Remedio: " + nombre + " - Valor de lista= $" + precioDeLista;
	}

}
