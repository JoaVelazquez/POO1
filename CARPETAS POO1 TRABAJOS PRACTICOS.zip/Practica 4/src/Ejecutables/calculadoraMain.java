package Ejecutables;

import Domain.Calculadora;

public class calculadoraMain {

		public static void main(String[] args) {
			
			try {
				System.out.println("Resultado = "+ Calculadora.dividir(7,0));
			}
			catch (Exception exception){
				System.out.println(exception.getMessage());
			}
		}
}
