package Domain;

public class dividirConCero extends Exception{
	
	public dividirConCero() {
		super("Error! No se puede dividir por cero.");
	}

}
