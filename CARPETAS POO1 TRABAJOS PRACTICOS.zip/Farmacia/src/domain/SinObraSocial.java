package domain;

public class SinObraSocial extends ObraSocial {
	
	public SinObraSocial() {
		super ("");
	}
	public double CalculaDescuento(Remedios remedio) {
		return remedio.getPrecioDeLista();
	}
}
 