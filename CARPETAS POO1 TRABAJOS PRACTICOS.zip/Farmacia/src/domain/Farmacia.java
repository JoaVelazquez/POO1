package domain;
import java.util.ArrayList;
import java.util.List;

public class Farmacia {

	
		static List<Remedios> listaDeRemedios;
		
		public Farmacia() {
			
			listaDeRemedios = new ArrayList<>();
		}
		
		public List<Remedios> getListaDeRemedios(){
			return listaDeRemedios;
		}
		
		public void agregarRemedio( Remedios remedio) {
			listaDeRemedios.add(remedio);
		}
		public void eliminarRemedio( Remedios remedio) {
			listaDeRemedios.remove(remedio);
		}
		
		@Override
		public String toString() {
			return "\nLa farmacia fue creada con exito!";
		}
		
		public double CalcularImporteAPagar( Cliente cliente, Remedios remedio, MetodoDePago metodoDePago ) {
			
			ObraSocial obraSocial = cliente.getObraSocial();
			
			double precioObraSocial = obraSocial.CalculaDescuento(remedio);
			double precioFinal = metodoDePago.CalculaPrecio(precioObraSocial);
			return precioFinal;
		}
}
