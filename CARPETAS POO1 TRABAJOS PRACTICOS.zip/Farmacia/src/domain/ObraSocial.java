package domain;

public class ObraSocial {
	
	private String nombre;

	public ObraSocial(String nombre) {
		this.nombre = nombre;
	}
	
	public double CalculaDescuento(Remedios remedio) {
		if( remedio.getNecesitaReceta() ) {
			return remedio.getPrecioDeLista() * 0.6;
		}else {
			return remedio.getPrecioDeLista() * 0.9;
		}
	}
	
	@Override
	public String toString() {
		return nombre;
	}
	
	//SETTERS Y GETTERS
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
}
