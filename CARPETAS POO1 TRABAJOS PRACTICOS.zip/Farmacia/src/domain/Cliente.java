package domain;

public class Cliente {

		private String nombre;
		private ObraSocial obraSocial;
		
		public Cliente(String nombre, ObraSocial obraSocial) {
			
			this.nombre = nombre;
			this.obraSocial = obraSocial;
			
		}
		
		@Override
		public String toString() {
			return ">>>Me llamo " + nombre + " y mi obra Social es: " + obraSocial;
		}
		
		//SETTERS Y GETTERS
		public void setNombre(String nombre) {
			this.nombre = nombre;
		}
		public void setObraSocial(ObraSocial obraSocial) {
			this.obraSocial = obraSocial;
		}
		public String getNombre() {
			return nombre;
		}
		public ObraSocial getObraSocial() {
			return obraSocial;
		}
		
		
}
