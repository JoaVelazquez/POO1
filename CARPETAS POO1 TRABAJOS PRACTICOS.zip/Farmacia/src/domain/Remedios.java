package domain;

public class Remedios {
	
	private String nombre;
	private double precioDeLista;
	private boolean necesitaReceta;
	
	public Remedios(String nombre, double precioDeLista ,boolean necesitaReceta) {
		
		this.nombre = nombre;
		this.precioDeLista = precioDeLista;
		this.necesitaReceta = necesitaReceta;
	}
	
	@Override
	public String toString() {
		return "-Remedio: "+ nombre +"\n-Precio de lista: $"+ precioDeLista;
	}
	//SETTERS Y  GETTERS
	
	public double getPrecioDeLista() {
		return precioDeLista;
	}
	public void setPrecioDeLista(double precioDeLista) {
		this.precioDeLista = precioDeLista;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public boolean getNecesitaReceta() {
		return necesitaReceta;
	}
	public void setNecesitaReceta(boolean necesitaReceta) {
		this.necesitaReceta = necesitaReceta;
	}
	
	

}
