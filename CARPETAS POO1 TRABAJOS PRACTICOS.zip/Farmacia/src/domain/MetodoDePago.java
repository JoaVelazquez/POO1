package domain;

public abstract class MetodoDePago {
	
		public abstract double CalculaPrecio( double precio ) {
		}
}

