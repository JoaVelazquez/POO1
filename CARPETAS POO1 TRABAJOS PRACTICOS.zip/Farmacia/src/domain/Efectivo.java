package domain;

public class Efectivo extends MetodoDePago{

		@Override
		public double CalculaPrecio( double precio ) {
			return precio*0.9;
		}
}
