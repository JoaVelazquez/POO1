package domain;

public class Tarjeta extends MetodoDePago {

		@Override
		public double CalculaPrecio(double precio) {
			return precio*1.05;
		}
}
