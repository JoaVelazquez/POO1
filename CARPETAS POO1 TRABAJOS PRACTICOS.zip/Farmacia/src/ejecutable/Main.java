package ejecutable;

import domain.*;


public class Main {

	public static void main(String[] args) {

		//Creamos farmacia
		Farmacia farmacia = new Farmacia();
		System.out.println(farmacia.toString());
		
		//Creamos remedios
		Remedios dermaglos = new Remedios("Dermaglos",100, false);
		Remedios adermicina = new Remedios("Adermicina",240,false);
		Remedios macril = new Remedios("Macril",180, true);
		
		//Los agregamos a la lista de la farmacia
		farmacia.agregarRemedio(dermaglos);
		farmacia.agregarRemedio(adermicina);
		farmacia.agregarRemedio(macril);
	
		//Imprimimos la lista
		System.out.println("\n Lista de remedios: ");
		for( Remedios remedio: farmacia.getListaDeRemedios()) {
			System.out.println(remedio.toString());
		}
		
		//Clientes
		System.out.println("\nClientes cargados:");
		Cliente carlos = new Cliente("Carlos",new ObraSocial("OSPLAD"));
		System.out.println(carlos.toString());
	
		Cliente ana = new Cliente("Ana", new SinObraSocial());
		System.out.println(ana.toString());

		Cliente fernando = new Cliente("Fernando", new ObraSocial("OSDE"));
		System.out.println(fernando.toString());
		
		//Compras
		System.out.println("\nSe realizan las compras");
		
		System.out.println("Compra 1: Total a pagar= $" + farmacia.CalcularImporteAPagar(carlos,macril, new Efectivo()));
		System.out.println("Compra 2: Total a pagar= $" + farmacia.CalcularImporteAPagar(ana,dermaglos, new Tarjeta()));
		System.out.println("Compra 3: Total a pagar= $" + farmacia.CalcularImporteAPagar(fernando,adermicina, new Tarjeta()));
	}

}
