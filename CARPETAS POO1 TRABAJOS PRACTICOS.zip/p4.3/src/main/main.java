package main;

import domain.Circulo;

public class main {

	public static void main(String[] args) {
		
		try {
			Circulo circulo = new Circulo(0);
		}catch (Exception exception) {
			exception.printStackTrace();
			//System.out.println(exception.getMessage());
		}

	}

}
