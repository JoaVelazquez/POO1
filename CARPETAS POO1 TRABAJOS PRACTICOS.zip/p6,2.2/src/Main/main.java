package Main;

import java.util.List;
import Domain.Empleado;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

public class main {

	public static void main(String[] args) throws IOException {
			
		String stringAEscribir = null;
		String stringLeido = null;
		BufferedReader archLectura = null;
		PrintWriter archEscritura = null;
		
		List<Empleado> listaEmpleados = new ArrayList<>();
		
		listaEmpleados.add(new Empleado("Joaquin","Apellido",154369783,151801639));
		listaEmpleados.add(new Empleado("Agustin","Massieri",134374783,151801639));
		listaEmpleados.add(new Empleado("Gonzalo","Paredes",152349754,152342342));
		listaEmpleados.add(new Empleado("Giuliano","Bovari",123423432,156567565));
		
		try {
			
			archEscritura = new PrintWriter( new FileWriter("Empleados.csv"));
			for( Empleado empleado : listaEmpleados) {
				
				stringAEscribir = new String( empleado.getNombre() +","+
						empleado.getApellido() +","+ empleado.getTelefono()+","+
						empleado.getTelefono());
				archEscritura.println(stringAEscribir);
				
			}
			
		}finally {
			if( archEscritura != null ) {
				archEscritura.close();
			}
		}
		try {
			archLectura = new BufferedReader( new FileReader("Empleados.csv"));
			
			stringLeido = archLectura.readLine();
			
			while( stringLeido != null ) {
				System.out.println(stringLeido);
				stringLeido = archLectura.readLine();
			}
		}finally {
			
			if( archEscritura != null ) {
				archEscritura.close();
			}
		}
	}

}
