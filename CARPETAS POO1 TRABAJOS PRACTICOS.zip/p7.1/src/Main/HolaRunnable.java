package Main;

public class HolaRunnable implements Runnable {
	
	public void run() {
		//yield();
		System.out.println("Hola Mundo Runnable");
	}
}