package Main;

public class HolaThread extends Thread {
	
	
	public void run() {
		yield();
		System.out.println("Hola Mundo Thread");
	}

}
