package Main;

public class main {

	public static void main(String[] args) {
		
		Thread hilo = new HolaThread();
		Thread corre= new Thread(new HolaRunnable());
		
		hilo.start();
		corre.start();
		
		System.out.println("fin main");
	}

}
