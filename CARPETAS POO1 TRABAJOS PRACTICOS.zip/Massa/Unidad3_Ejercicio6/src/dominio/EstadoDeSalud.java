package dominio;

public abstract class EstadoDeSalud {


}