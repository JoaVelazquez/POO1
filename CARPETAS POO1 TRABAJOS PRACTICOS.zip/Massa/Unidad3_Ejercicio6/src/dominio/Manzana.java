package dominio;

public class Manzana {

	public int cantidadDeCalorias() {
		return 2;
	}
}
