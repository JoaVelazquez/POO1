package dominio;

public class Gordo extends EstadoDeSalud {

	@Override
	public String toString() {

		return "Gordo";
	}
	
}
