package dominio;

public class Saludable extends EstadoDeSalud{

	@Override
	public String toString() {

		return "Saludable";
	}
}
