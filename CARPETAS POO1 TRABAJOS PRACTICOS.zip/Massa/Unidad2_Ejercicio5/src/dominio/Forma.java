package dominio;

public abstract class Forma {

	public abstract double calcularArea();
}
