package dominio;

public class Producto {

	private String nombre;
	private double precioDeLista;
	private double precioModificado;
	public Categoria categoria;
	
	public Producto(String nombre, double precioDeLista, Categoria categoria) {
		this.nombre = nombre;
		this.precioDeLista = precioDeLista;
		this.categoria = categoria;
		this.precioModificado = categoria.getPrecio(precioDeLista);
	}
	
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	public void setPrecioDeLista(double precioDeLista) {
		this.precioDeLista = precioDeLista;
	}
	
	public void setPrecioModificado(double precioDeLista) {
		this.precioModificado = precioDeLista * categoria.getPrecio(precioDeLista);
	}
	
	public void setCategoria(Categoria categoria) {
		this.categoria = categoria;
	}
	
	public String getNombre() {
		return nombre;
	}
	
	public double getPrecioDeLista() {
		return precioDeLista;
	}
	
	public double getPrecioModificado() {
		return precioModificado;
	}
	
	public Categoria getCategoria() {
		return categoria;
	}
	
	@Override
	public String toString() {
		return "Nombre: " + nombre + " - Precio De Lista: $" + precioDeLista ;
	}
	
	
}
