package dominio;

public abstract class IVA {
	
	public abstract double calcularIVA(double precio);
}
