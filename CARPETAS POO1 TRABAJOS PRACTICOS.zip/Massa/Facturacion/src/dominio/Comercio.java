package dominio;

import java.util.ArrayList;
import java.util.List;

public class Comercio {

	List<Producto> listaDeProductosDisponibles;
	private String nombre;
	
	public Comercio(String nombre) {
		this.nombre = nombre;
		listaDeProductosDisponibles = new ArrayList<>();
	}
	
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	public String getNombre() {
		return nombre;
	}
	
	public void agregarProducto(Producto producto) {
		listaDeProductosDisponibles.add(producto);
	}
	
	public void eliminarProducto(Producto producto) {
		listaDeProductosDisponibles.remove(producto);
	}
	
	public void imprimirListaDeProductosDisponibles(){
		for(Producto producto: listaDeProductosDisponibles) {
			System.out.println(producto);
		}
	}
	
}
