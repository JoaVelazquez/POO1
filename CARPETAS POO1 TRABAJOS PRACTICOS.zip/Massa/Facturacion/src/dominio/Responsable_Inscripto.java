package dominio;

public class Responsable_Inscripto extends IVA {
	
	@Override
	public double calcularIVA(double precio) {
		return precio * 1.105;
	}

}
