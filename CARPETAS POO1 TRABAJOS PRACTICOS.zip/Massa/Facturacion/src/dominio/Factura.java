package dominio;

import java.util.ArrayList;
import java.util.List;

public class Factura {

	List<Producto> listaDeProductosComprados;
	private Cliente cliente;
	
	public Factura(Cliente cliente) {
		listaDeProductosComprados = new ArrayList<>();
		this.cliente = cliente;
	}
	
	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}
	
	public Cliente getCliente() {
		return cliente;
	}
	
	public void agregarProductoComprado(Producto producto) {
		listaDeProductosComprados.add(producto);
	}
	
	public void eliminarProducto(Producto producto) {
		listaDeProductosComprados.remove(producto);
	}
	
	public double calcularPrecioFactura() {
		
		double precioFactura = 0;
		
		for(Producto producto: listaDeProductosComprados) {
			precioFactura = precioFactura + producto.getPrecioModificado();
		}
		
		return cliente.getIVA().calcularIVA(precioFactura);
	}
	
	public void imprimirListaDeProductosComprados() {
		for(Producto producto: listaDeProductosComprados) {
			System.out.println(producto);
		}
	}
}
