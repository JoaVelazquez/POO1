package dominio;

public abstract class Categoria {

	
	public abstract double getPrecio(double precio);
}
