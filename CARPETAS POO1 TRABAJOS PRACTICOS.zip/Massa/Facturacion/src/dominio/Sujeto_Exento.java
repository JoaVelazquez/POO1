package dominio;

public class Sujeto_Exento extends IVA {

	@Override
	public double calcularIVA(double precio) {
		return precio;
	}
}
