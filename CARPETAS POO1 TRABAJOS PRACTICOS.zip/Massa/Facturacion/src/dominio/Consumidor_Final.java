package dominio;

public class Consumidor_Final extends IVA {

	@Override
	public double calcularIVA(double precio) {
		return precio * 1.21;
	}
}
