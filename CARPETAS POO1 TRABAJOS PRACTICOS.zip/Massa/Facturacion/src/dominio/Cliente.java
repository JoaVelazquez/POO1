package dominio;

public class Cliente {

	private String nombre;
	private IVA iva;
	
	public Cliente(String nombre, IVA iva) {
		this.nombre = nombre;
		this.iva = iva;
	}
	
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	public void setIVA(IVA iva) {
		this.iva = iva;
	}
	
	public String getNombre() {
		return nombre;
	}
	
	public IVA getIVA() {
		return iva;
	}
	

}

