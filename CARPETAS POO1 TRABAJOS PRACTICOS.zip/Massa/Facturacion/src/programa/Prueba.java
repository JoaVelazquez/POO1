package programa;

import dominio.*;

public class Prueba {

	public static void main(String[] args) {

		Comercio unComercio = new Comercio("Disco");
		
		Producto computadora = new Producto("Computadora", 60000, new Importado());
		Producto setDeVajilla = new Producto("Set de Vajilla", 7000, new Nacional());
		Producto heladera = new Producto("Heladera", 45000, new Nacional());
		
		Cliente Florencia = new Cliente("Florencia", new Responsable_Inscripto());
		Cliente Luis = new Cliente("Luis", new Consumidor_Final());
		Cliente Pedro = new Cliente("Pedro", new Sujeto_Exento());

		
		unComercio.agregarProducto(computadora);
		unComercio.agregarProducto(setDeVajilla);
		unComercio.agregarProducto(heladera);
		
		System.out.println("\nIMPRIMO LA LISTA DE PRODUCTOS DISPONIBLES EN EL COMERCIO:");
		unComercio.imprimirListaDeProductosDisponibles();

		
		Factura factura_Florencia = new Factura(Florencia);
		Factura factura_Luis = new Factura(Luis);
		Factura factura_Pedro = new Factura(Pedro);

		
		factura_Florencia.agregarProductoComprado(computadora);
		factura_Luis.agregarProductoComprado(setDeVajilla);
		factura_Pedro.agregarProductoComprado(heladera);
		
		System.out.println("\nIMPRIMO LA LISTA DE PRODUCTOS EN EL CARRITO DE FLORENCIA:");
		factura_Florencia.imprimirListaDeProductosComprados();
		
		System.out.println("\nIMPRIMO LA LISTA DE PRODUCTOS EN EL CARRITO DE LUIS:");
		factura_Luis.imprimirListaDeProductosComprados();
		
		System.out.println("\nIMPRIMO LA LISTA DE PRODUCTOS EN EL CARRITO DE PEDRO:");
		factura_Pedro.imprimirListaDeProductosComprados();
		
		System.out.println("\n>> La factura de " + Florencia.getNombre() + " es de $" + factura_Florencia.calcularPrecioFactura());
		System.out.println("\n>> La factura de " + Luis.getNombre() + " es de $" + factura_Luis.calcularPrecioFactura());
		System.out.println("\n>> La factura de " + Pedro.getNombre() + " es de $" + factura_Pedro.calcularPrecioFactura());

	}

}
