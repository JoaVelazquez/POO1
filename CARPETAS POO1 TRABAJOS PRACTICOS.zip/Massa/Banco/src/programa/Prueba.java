package programa;

import dominio.*;

public class Prueba {

	public static void main(String[] args) {

		Banco Galicia = new Banco("Galicia");
		System.out.println("\n>> Creo el Banco");
		
		Cliente Agustin = new Cliente("Agustin", 42566741, 2042566741, 10000);
		System.out.println("\n>> Creo el Cliente");

		Galicia.agregarCliente(Agustin);
		System.out.println("\n>> Agrego al Cliente al Banco");

		System.out.println("\n>> Muestro el saldo de Agustin:");
		System.out.println("\n  Saldo: $" + Agustin.getSaldo());
		
		Galicia.realizarOperacion(Agustin, new Deposito(), 100);
		System.out.println("\n>> Realizo un deposito de $100");
		System.out.println("\n   Saldo de Agustin: $" + Agustin.getSaldo());
		
		Galicia.realizarOperacion(Agustin, new Transferencia(), 100);
		System.out.println("\n>> Realizo una transferencia de $100");
		System.out.println("\n   Saldo de Agustin: $" + Agustin.getSaldo());
		
		Galicia.realizarOperacion(Agustin, new Extraccion(), 100);
		System.out.println("\n>> Realizo una Extraccion de $100");	
		System.out.println("\n>> Saldo de Agustin: $" + Agustin.getSaldo());
		
		
		Galicia.imprimirUltimosTresMovimientos(Agustin);
		

	}
	

}
