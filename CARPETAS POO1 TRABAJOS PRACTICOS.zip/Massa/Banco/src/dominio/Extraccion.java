package dominio;

public class Extraccion extends Operacion{
	
	@Override
	public void realizarOperacion(Cliente cliente, double monto) {

		if( cliente.getSaldo() >= monto ) {
			cliente.agregarOperacion(new Extraccion());
			cliente.setSaldo(cliente.getSaldo() - monto);
		}else {
			System.out.println("Saldo Insuficiente!");
		}
		
	}
	
	@Override
	public String toString() {
		return "Extraccion";
	}

}
