package dominio;

import java.util.ArrayList;
import java.util.List;

public class Banco {

	static List<Cliente> listaDeClientes;
	
	private String nombre;
	
	public Banco(String nombre) {
		this.nombre =nombre;
		listaDeClientes = new ArrayList<>();
	}
	
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	public String getNombre() {
		return nombre;
	}
	
	public void agregarCliente(Cliente cliente) {
		listaDeClientes.add(cliente);
	}
	
	public void eliminarCliente(Cliente cliente) {
		listaDeClientes.remove(cliente);
	}
	
	public boolean esCliente(Cliente cliente) {
		for(Cliente clienteDeLaLista: listaDeClientes) {
			if(cliente == clienteDeLaLista) {
				return true;
			}
			else {
				return false;
			}
		}
		return false;
	}
	
	public List<Cliente> getListaDeOperacionesCliente(){
		return listaDeClientes;
	}
	
	public void imprimirUltimosTresMovimientos(Cliente cliente) {
	
		List<Operacion> listaDeOperaciones = cliente.getListaDeOperaciones();
		int largoDeLaLista = listaDeOperaciones.size();
		
		System.out.println("\n>> Ultimas 3 Operaciones de " + cliente.getNombre() + ": ");

		for ( int i = 0;  (i < 3 ) ; i++) {
			try {
				System.out.println("- " + listaDeOperaciones.get(largoDeLaLista - 1 - i));
			}catch(Exception e) {
				
			}
		}
	}
	
	public void realizarOperacion(Cliente cliente, Operacion operacion, double monto) {
		operacion.realizarOperacion(cliente, monto);
	}
	
}
