package dominio;

public class Deposito extends Operacion {

	@Override
	public void realizarOperacion(Cliente cliente, double monto) {

		cliente.agregarOperacion(new Deposito());
		cliente.setSaldo(cliente.getSaldo() + monto);
	}
	
	@Override
	public String toString() {
		return "Deposiito";
	}
}
