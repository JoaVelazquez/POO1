package dominio;

public abstract class Operacion {

	public abstract void realizarOperacion(Cliente cliente, double monto);
}
