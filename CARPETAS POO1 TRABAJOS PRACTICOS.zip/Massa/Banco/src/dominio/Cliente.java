package dominio;

import java.util.ArrayList;
import java.util.List;

public class Cliente {

	static List<Operacion> listaDeOperaciones;
	
	private String nombre;
	private double dni;
	private double numeroDeCuenta;
	private double saldo;
	
	public Cliente(String nombre, double dni, double numeroDeCuenta, double saldo)  {
		this.nombre = nombre;
		this.dni = dni;
		this.numeroDeCuenta = numeroDeCuenta;
		this.saldo = saldo;
		listaDeOperaciones = new ArrayList<>();
	}
	
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	public void setDNI(double dni) {
		this.dni = dni;
	}
	
	public void setNumeroDeCuenta(double numeroDeCuenta) {
		this.numeroDeCuenta = numeroDeCuenta;
	}
	
	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}
	
	public String getNombre() {
		return nombre;
	}
	
	public double getDNI() {
		return dni;
	}
	
	public double getNumeroDeCuenta() {
		return numeroDeCuenta;
	}
	
	public double getSaldo() {
		return saldo;
	}
	
	public void agregarOperacion(Operacion operacion) {
		listaDeOperaciones.add(operacion);
	}
	
	public void eliminarOperacion(Operacion operacion) {
		listaDeOperaciones.remove(operacion);
	}
	
	public List<Operacion> getListaDeOperaciones(){
		return listaDeOperaciones;
	}
}
