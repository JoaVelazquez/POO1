package dominio;

public abstract class Alimento {

	public abstract double darAporteEnergetico();
	
}
