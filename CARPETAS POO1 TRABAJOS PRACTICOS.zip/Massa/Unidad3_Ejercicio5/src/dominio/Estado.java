package dominio;

public abstract class Estado {
	
	public abstract boolean estaActivo();
	public abstract boolean noEstaActivo();
}
