package dominio;

public class Postre extends Alimento{
		
	public double darAporteEnergetico() {
		return 0;
	}
	
	@Override
	public String toString() {
		return "Postre";
	}

}
