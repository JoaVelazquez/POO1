package dominio;

public abstract class Animal {

	private String nombre;
	
	public Animal (String nombre) {
	}
}
