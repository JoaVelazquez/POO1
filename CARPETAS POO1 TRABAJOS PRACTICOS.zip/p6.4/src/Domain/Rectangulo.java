package Domain;

public class Rectangulo extends Figura {

		double base;
		double altura;
		
		public Rectangulo(double base, double altura) {
			
			this.altura = altura;
			this.base = base;
		}
		
		@Override
		public String toString() {
			
			return "Rectangulo[ base = "+base+"; altura = "+altura+"]";
		}
}
