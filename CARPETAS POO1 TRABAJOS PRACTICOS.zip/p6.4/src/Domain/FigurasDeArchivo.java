package Domain;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

public class FigurasDeArchivo {

		public static Figura crearFiguraDeArchivo(String nomArch) throws NoHayMasFigurasException{
			
			Figura figura = null;
			ObjectInputStream archLectura = null;
			
			try {
				
				archLectura = new ObjectInputStream(new FileInputStream(nomArch));
				figura = (Figura) archLectura.readObject();
				
				archLectura.close();
				
			}catch(ClassNotFoundException exception) {
				throw new NoHayMasFigurasException();
				
			}catch(IOException exception) {
				throw new NoHayMasFigurasException();
			}
			
			return figura;
		}
}
