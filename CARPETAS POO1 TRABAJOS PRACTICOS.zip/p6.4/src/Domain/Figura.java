package Domain;

import java.io.Serializable;

public abstract class Figura implements Serializable{

		
}
