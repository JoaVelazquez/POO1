 package Domain;

public class NoHayMasFigurasException extends Exception {

		public NoHayMasFigurasException() {
			super("No hay mas figuras");
		}
}
