package Domain;

public class Circulo extends Figura{
	
	double radio;
	
	public Circulo(double radio) {
		this.radio = radio;
	}
	
	@Override
	public String toString() {
		return "Circulo[ radio"+radio+"]";
	}

}
