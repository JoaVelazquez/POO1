package Main;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import Domain.*;
import Domain.Triangulo;

public class mian {

	public static void main(String[] args) throws IOException {
		
		/*
		Circulo circulo = new Circulo(5);
		Triangulo triangulo = new Triangulo(5,3);
		Rectangulo rectangulo = new Rectangulo(5,10);
		ObjectOutputStream archCirculo = null;
		ObjectOutputStream archTriangulo = null;
		ObjectOutputStream archRectangulo = null;
		
		try {
		
			archCirculo = new ObjectOutputStream(new FileOutputStream("circulo.fig"));
			archTriangulo = new ObjectOutputStream(new FileOutputStream("triangulo.fig"));
			archRectangulo = new ObjectOutputStream(new FileOutputStream("rectangulo.fig"));
			
			archCirculo.writeObject(circulo);
			archTriangulo.writeObject(triangulo);
			archRectangulo.writeObject(rectangulo);
			
		}catch(NoHayMasFigurasException exception) {
			System.out.println(exception);
		}
			finally {
			
			if(archCirculo != null && archTriangulo != null && archRectangulo != null ) {
				archCirculo.close();
				archTriangulo.close();
				archRectangulo.close();
			}
		*/
		try {
			System.out.println(FigurasDeArchivo.crearFiguraDeArchivo("circulo.fig"));
			//System.out.println(FigurasDeArchivo.crearFiguraDeArchivo("triangulo.fig"));
			//System.out.println(FigurasDeArchivo.crearFiguraDeArchivo("rectangulo.fig"));
			
		}catch(NoHayMasFigurasException exception) {
			System.out.println(exception);
		}
		
		}

	}
