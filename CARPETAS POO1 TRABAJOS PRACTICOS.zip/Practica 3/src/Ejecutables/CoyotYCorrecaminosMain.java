package Ejecutables;

import Programas.Coyote;
import Programas.Correcaminos;

public class CoyotYCorrecaminosMain {

		public static void main(String[] args) {
			
			Coyote coyote = new Coyote(100,100,2);
			Correcaminos correcaminos = new Correcaminos(20,50,0);
			
			System.out.println(coyote.toString());
			System.out.println(correcaminos.toString());
			
			System.out.println("Comienza la caceria!\n");
			
			if( coyote.comerCorrecaminos(correcaminos)) {
				System.out.println("El coyote corrio al correcaminos y se lo comio");
			}else {
				System.out.println("El coyote no alcanzo al correcaminos, vivira otro dia");
			}
		}
		
}
