package Ejecutables;


import Programas.Lobo;
import Programas.EstadoDeSalud;
import Programas.Persona;

public class LoboMain {

		public static void main(String[] args) {
			
			Programas.Lobo lobo = new Lobo(205);
			Persona persona = new Persona(85);
			
			System.out.println(lobo);
			System.out.println(persona);
			
			lobo.comerPersona(persona);
			lobo.correr(35);
			
		}
}
