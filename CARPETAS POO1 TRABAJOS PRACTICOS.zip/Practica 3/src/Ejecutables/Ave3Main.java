package Ejecutables;

import Programas.Ave3;
import Programas.Pez;
import Programas.Alpiste;
import Programas.Postre;

public class Ave3Main {

		public static void main(String[] args) {
			
			Ave3 piopio = new Ave3("Piopio");
			System.out.println(piopio.toString());
			Pez nemo = new Pez(4);
			Postre postrecito = new Postre();
			Alpiste alpiste = new Alpiste(12);
			
			piopio.comer(nemo);
			piopio.comer(postrecito);
			piopio.comer(alpiste);
			piopio.volar(20);
		}

}
