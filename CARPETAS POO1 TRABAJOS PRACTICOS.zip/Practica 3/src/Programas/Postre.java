package Programas;

public class Postre extends Alimento{

		public double energiaAportada() {
			return 0;
		}
		@Override
		public String toString() {
			return "Postre";
		}
}
