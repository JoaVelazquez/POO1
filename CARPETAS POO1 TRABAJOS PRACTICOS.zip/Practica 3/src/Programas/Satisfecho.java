package Programas;

public class Satisfecho extends Estado {
		
		@Override
		public String toString() {
			return "Satisfecho";
		}
		public boolean activo() {
			return true;
		}
		public boolean inactivo() {
			return false;
		}
}
