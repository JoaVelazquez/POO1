package Programas;

public class Lobo {
	
	private double grasa;
	private EstadoDeSalud estado;
	
	public Lobo(double grasa) {
		
		setGrasa(grasa);
		
	}
	
	private void setGrasa(double grasa) {
		this.grasa = grasa;
		
		if( grasa > 200 ) {
			estado = new Gordo();
		}else {
			estado = new Saludable();
		}
		
	}
	
	public EstadoDeSalud getEstado() {
		return estado;
	}
	
	public double getGrasa() {
		return grasa;
	}
	
	public void mostrarEstado(EstadoDeSalud estado) {
		
		System.out.println("Estado:"+estado);
		
	}
	
	public void comerPersona(Persona persona) {
		
		double pesoPersona = persona.getPeso();
		double grasaAdicional = pesoPersona/10;
		setGrasa( grasa + grasaAdicional);
		System.out.println("El lobo se comio una persona y ahora su grasa es de:"+grasa);
	}
	public void correr(double minutos) {
		double grasaEliminada = 2*minutos;
		setGrasa(grasa-grasaEliminada);
		System.out.println("El lobo corrio "+minutos+"y ahora tiene "+grasa+"g de grasa");
	}
	
	
	@Override
	public String toString() {
		return ">> Lobo con grasa = "+ grasa;
	}
}
