package Programas;

public abstract class EstadoDeSalud {

}
