package Programas;

public class Lugar {

	
		private String nombreLugar;
		private int dist;
		
		public Lugar(String nombreLugar, int dist) {
				
				this.nombreLugar = nombreLugar;
				this.dist = dist;
				
		}
		
		@Override
		public String toString() {
			
			return "Localidad: "+nombreLugar+"-Distancia: "+dist+"km.";
			
		}
		
		public static int distEntreLugares(Lugar in, Lugar fin) {
			
			int dif;
			
			dif = Math.abs(in.getDistancia() - fin.getDistancia());
			
			return dif;
			
		}
		
		public void setNombre(String nombreLugar) {
			
			this.nombreLugar = nombreLugar;
			
		}
		public void setDistancia(int dist) {
			
			this.dist = dist;
			
		}
		public String getNombre() {
			
			return nombreLugar;
			
		}
		public int getDistancia() {
			
			return dist;
		}
}
