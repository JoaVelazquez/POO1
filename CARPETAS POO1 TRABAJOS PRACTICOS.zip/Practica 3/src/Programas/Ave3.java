package Programas;

public class Ave3 {
	
		private String nombre;
		private double energia;
		private Estado satisfecho;
		private Estado empachado;
		
		public Ave3(String nombre) {
			
			this.nombre = nombre;
			setEnergia(100);
		}
		
		@Override
		public String toString() {
			
			return nombre + " es un ave con " + energia + "J de energia.";
		}
		
		public void setEnergia(double energia) {
			
			this.energia = energia;
			
			if( energia>100 ) {
				this.empachado = new Empachado();
			}else if( energia>50 && energia<100) {
				this.satisfecho = new Satisfecho();
			}
		}
		
		public double getEnergia() {
			return energia;
		}
		
		public void setNombre(String nombre) {
			this.nombre = nombre;
		}
		public String getNombre() {
			return nombre;
		}
		
		public boolean hambre() {
			
			if ( Satisfecho.inactivo() && Empachado.inactivo()) {
				
				return true;
			}
			return false;
		}
		
		public void volar( int dist ) {
			setEnergia(energia-dist-10);
			System.out.println("Volo "+dist+ "km y tiene "+energia+"J de energia");
		}
		public void comer(Alimento alimento) {
			setEnergia(energia+alimento.energiaAportada());
			System.out.println("Se comio su alimento y ahora tiene"+energia+"J de energia");
		}
		
}
