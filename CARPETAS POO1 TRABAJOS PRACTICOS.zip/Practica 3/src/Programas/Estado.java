package Programas;

public abstract class Estado {
	
		public abstract boolean activo();
		public abstract boolean inactivo();

}
