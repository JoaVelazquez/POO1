package Programas;

public class Coyote extends Animal{
	
	public Coyote(int peso, int energia, int posicion) {
		super( peso,energia,posicion);
		}
	@Override
	public String toString() {
		
		return ">>>Coyote:\n\tPeso: "+peso+"kg.\n\tEnergia: "+energia+"J\n\tPosicion: "+posicion;
	}
	public double obtenerVel() {
		
		double velocidad = 5+(energia/10);
		return Math.abs(velocidad);
		
	}
	
	public boolean puedeAtrapar (Correcaminos correcaminos) {
		
		double velCorrecaminos = correcaminos.obtenerVel();
		double velCoyote = this.obtenerVel(); 
		
		if( velCoyote > velCorrecaminos ) {
			return true;
		}
		return false;
	}
	
	public boolean correrCorrecaminos(Correcaminos correcaminos) {
		
		double dist = Math.abs( correcaminos.posicion - posicion);
		double velCoyote = this.obtenerVel();
		
		if( puedeAtrapar(correcaminos) && energia> (0.5*velCoyote*dist) ) {
			energia -= 0.5*velCoyote*dist;
			posicion = correcaminos.posicion;
			return true;
		}
		return false;
		
	}
	
	public boolean comerCorrecaminos(Correcaminos correcaminos) {
		
		if( correrCorrecaminos(correcaminos) ) {
			energia += 12;
			peso += correcaminos.peso;
			return true;
		}
		return false;
	}
	
	
}

