package Programas;

public class Ave {

		private String nombre;
		private double energia;
		
		public Ave(String nombre) {
			
			this.nombre = nombre;
			energia = 100;
			
		}
		
		@Override
		public String toString() {
			
			return "Nombre: " + nombre + "\nEnergia: " + energia ;
			
		}
		
		public String volar(int dist) {
			
			if(energia> dist+10) {//son los 10J fijos + 1J/km
				
				energia = energia -( 10+dist );
				return "Pudo volar " + dist + "km!";
				
			}
			return "No pudo volar los " + dist + "km por falta de energia.";
		}
		
		public String comer(double gramos) {
			
			energia+= gramos*4;
			return  "Comio " + gramos + "gramos de comida.";
			
		}
		
		public void setNombre(String nombre) {
			
			this.nombre = nombre;
			
		}
		
		public void setEnergia(double energia) {
			
			this.energia = energia;
			
		}
		
		public String getNombre() {
			
			return nombre;
			
		}
		
		public double getEnergia() {
			
			return energia;
			
		}

}
