package Programas;

public class Empachado extends Estado {

			
		@Override
		public String toString() {
			return "Empachado";
		}
		public boolean activo() {
			return true;
		}
		public boolean inactivo() {
			return false;
		}
}
