package Programas;

public class Alpiste extends Alimento {

		private double gramos;
		
		@Override
		public String toString() {
			return "Alpiste de "+ gramos +"gr";
		}
		
		public Alpiste(double gramos) {
			this.gramos = gramos;
		}
		
		public double energiaAportada() {
			return 4*gramos;
		}
}
