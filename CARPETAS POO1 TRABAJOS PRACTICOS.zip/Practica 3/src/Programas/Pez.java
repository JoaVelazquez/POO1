package Programas;

public class Pez extends Alimento {
	
		private int edad;
		
		public Pez(int edad) {
			this.edad = edad;
		}
		
		@Override
		public String toString() {
			return "Pez de " + edad + "Anios de edad";
		}
		
		public double energiaAportada() {
			return Math.sqrt(edad);
		}

}
