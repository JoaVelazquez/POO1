package Programas;

public abstract class Alimento {

		public abstract double energiaAportada();
		
}
