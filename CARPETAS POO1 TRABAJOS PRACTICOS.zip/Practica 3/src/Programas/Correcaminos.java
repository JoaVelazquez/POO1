package Programas;

public class Correcaminos extends Animal {

		public Correcaminos(int peso, int energia, int posicion) {
			
			super(peso, energia, posicion);
		}
		
		@Override
		public String toString() {
			
			return ">>>Correcaminos:\n\tPeso: "+peso+"kg.\n\tEnergia: "+energia+"J\n\tPosicion: "+posicion;
		}
		
		public double obtenerVel() {
			
			double velocidad = 10-peso;
			return Math.abs(velocidad);
			
		}
}
