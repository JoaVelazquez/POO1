package Main;

import java.util.List;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.util.ArrayList;
import Domain.*;

public class main {

	public static void main(String[] args) throws IOException {
			

		DataInputStream archLectura = null;
		DataOutputStream archEscritura = null;
		D
		List<Empleado> listaEmpleados = new ArrayList<>();
		
		listaEmpleados.add(new Empleado("Joaquin","Apellido",154369783,151801639));
		listaEmpleados.add(new Empleado("Agustin","Massieri",134374783,151801639));
		listaEmpleados.add(new Empleado("Gonzalo","Paredes",152349754,152342342));
		listaEmpleados.add(new Empleado("Giuliano","Bovari",123423432,156567565));
		
		try {
			
			archEscritura = new DataOutputStream(new BufferedOutputStream(new FileOutputStream("Empleados.csv")));
			for( Empleado empleado : listaEmpleados) {
				
				archEscritura.writeUTF(empleado.getNombre());
				archEscritura.writeUTF(empleado.getApellido());
				archEscritura.writeInt(empleado.getTelefono());
				archEscritura.writeInt(empleado.getLegajo());
				
			}
			
		}finally {
			if( archEscritura != null ) {
				archEscritura.close();
			}
		}
		
		int legajoLeido;
		String nombreLeido;
		String apellidoLeido;
		int telefonoLeido;
		
		try {
			archLectura = new DataInputStream(new BufferedInputStream(new FileInputStream("Empleados.csv")));
			
			while(true) {
				
				nombreLeido = archLectura.readUTF();
				apellidoLeido = archLectura.readUTF();
				telefonoLeido = archLectura.readInt();
				legajoLeido = archLectura.readInt();
				System.out.println(">>"+nombreLeido+","+apellidoLeido+","+
									telefonoLeido+","+legajoLeido);
			}
		}catch(EOFException exception) {
			System.out.println("\nLectura finalizada!");
		}finally {
			
			if(archLectura != null) {
				archLectura.close();
			}
			
		}
	}

}
